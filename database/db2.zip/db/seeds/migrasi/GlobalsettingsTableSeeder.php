<?php

use Illuminate\Database\Seeder;

class GlobalsettingsTableSeeder extends Seeder
{

    /**
     * Auto generated seed file
     *
     * @return void
     */
    public function run()
    {
        

        \DB::table('globalsettings')->delete();
        
        \DB::table('globalsettings')->insert(array (
            0 => 
            array (
                'id' => '1',
                'parameter' => 'length_number',
                'value' => '3',
                'created_at' => '2018-09-09 07:00:00.000',
                'updated_at' => '2018-09-09 07:00:00.000',
                'deleted_at' => NULL,
                'created_by' => '1',
                'updated_by' => NULL,
                'deleted_by' => NULL,
                'inactive_at' => NULL,
                'inactive_by' => NULL,
            ),
            1 => 
            array (
                'id' => '2',
                'parameter' => 'aanwijzing_date',
                'value' => '7',
                'created_at' => '2018-09-11 00:00:00.000',
                'updated_at' => '2018-09-11 00:00:00.000',
                'deleted_at' => NULL,
                'created_by' => '1',
                'updated_by' => NULL,
                'deleted_by' => NULL,
                'inactive_at' => NULL,
                'inactive_by' => NULL,
            ),
            2 => 
            array (
                'id' => '3',
                'parameter' => 'penawaran1_date',
                'value' => '7',
                'created_at' => '2018-09-11 00:00:00.000',
                'updated_at' => '2018-09-11 00:00:00.000',
                'deleted_at' => NULL,
                'created_by' => '1',
                'updated_by' => NULL,
                'deleted_by' => NULL,
                'inactive_at' => NULL,
                'inactive_by' => NULL,
            ),
            3 => 
            array (
                'id' => '4',
                'parameter' => 'klarifikasi1_date',
                'value' => '7',
                'created_at' => '2018-09-11 00:00:00.000',
                'updated_at' => '2018-09-11 00:00:00.000',
                'deleted_at' => NULL,
                'created_by' => '1',
                'updated_by' => NULL,
                'deleted_by' => NULL,
                'inactive_at' => NULL,
                'inactive_by' => NULL,
            ),
            4 => 
            array (
                'id' => '5',
                'parameter' => 'penawaran2_date',
                'value' => '7',
                'created_at' => '2018-09-11 00:00:00.000',
                'updated_at' => '2018-09-11 00:00:00.000',
                'deleted_at' => NULL,
                'created_by' => '1',
                'updated_by' => NULL,
                'deleted_by' => NULL,
                'inactive_at' => NULL,
                'inactive_by' => NULL,
            ),
            5 => 
            array (
                'id' => '6',
                'parameter' => 'klarifikasi2_date',
                'value' => '7',
                'created_at' => '2018-09-11 00:00:00.000',
                'updated_at' => '2018-09-11 00:00:00.000',
                'deleted_at' => NULL,
                'created_by' => '1',
                'updated_by' => NULL,
                'deleted_by' => NULL,
                'inactive_at' => NULL,
                'inactive_by' => NULL,
            ),
            6 => 
            array (
                'id' => '7',
                'parameter' => 'penawaran3_date',
                'value' => '7',
                'created_at' => '2018-09-11 00:00:00.000',
                'updated_at' => '2018-09-11 00:00:00.000',
                'deleted_at' => NULL,
                'created_by' => '1',
                'updated_by' => NULL,
                'deleted_by' => NULL,
                'inactive_at' => NULL,
                'inactive_by' => NULL,
            ),
            7 => 
            array (
                'id' => '8',
                'parameter' => 'limit_bangun',
                'value' => '90',
                'created_at' => '2018-10-31 17:00:00.000',
                'updated_at' => '2018-10-31 17:00:00.000',
                'deleted_at' => NULL,
                'created_by' => '1',
                'updated_by' => NULL,
                'deleted_by' => NULL,
                'inactive_at' => NULL,
                'inactive_by' => NULL,
            ),
            8 => 
            array (
                'id' => '9',
                'parameter' => 'ppn',
                'value' => '10',
                'created_at' => '2018-11-01 17:00:00.000',
                'updated_at' => '2018-11-01 17:00:00.000',
                'deleted_at' => NULL,
                'created_by' => '1',
                'updated_by' => NULL,
                'deleted_by' => NULL,
                'inactive_at' => NULL,
                'inactive_by' => NULL,
            ),
        ));
        
        
    }
}