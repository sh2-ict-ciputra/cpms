<?php

use Illuminate\Database\Seeder;

class UnitTypeCategoriesTableSeeder extends Seeder
{

    /**
     * Auto generated seed file
     *
     * @return void
     */
    public function run()
    {
        

        \DB::table('unit_type_categories')->delete();
        
        \DB::table('unit_type_categories')->insert(array (
            0 => 
            array (
                'id' => '1',
                'unit_type_id' => '79',
                'category_project_id' => '4',
                'created_at' => '2018-11-13 14:01:11.233',
                'updated_at' => '2018-11-13 14:01:11.233',
                'created_by' => '37',
                'updated_by' => NULL,
                'deleted_at' => NULL,
                'deleted_by' => NULL,
                'inactive_at' => NULL,
                'inactive_by' => NULL,
                'type' => '4',
            ),
            1 => 
            array (
                'id' => '2',
                'unit_type_id' => '86',
                'category_project_id' => '5',
                'created_at' => '2018-11-13 14:12:42.337',
                'updated_at' => '2018-11-13 14:12:42.337',
                'created_by' => '37',
                'updated_by' => NULL,
                'deleted_at' => NULL,
                'deleted_by' => NULL,
                'inactive_at' => NULL,
                'inactive_by' => NULL,
                'type' => '1',
            ),
            2 => 
            array (
                'id' => '3',
                'unit_type_id' => '86',
                'category_project_id' => '6',
                'created_at' => '2018-11-13 14:13:03.903',
                'updated_at' => '2018-11-13 14:13:03.903',
                'created_by' => '37',
                'updated_by' => NULL,
                'deleted_at' => NULL,
                'deleted_by' => NULL,
                'inactive_at' => NULL,
                'inactive_by' => NULL,
                'type' => '1',
            ),
            3 => 
            array (
                'id' => '4',
                'unit_type_id' => '80',
                'category_project_id' => '7',
                'created_at' => '2018-11-13 14:13:41.523',
                'updated_at' => '2018-11-13 14:13:41.523',
                'created_by' => '37',
                'updated_by' => NULL,
                'deleted_at' => NULL,
                'deleted_by' => NULL,
                'inactive_at' => NULL,
                'inactive_by' => NULL,
                'type' => '1',
            ),
            4 => 
            array (
                'id' => '5',
                'unit_type_id' => '90',
                'category_project_id' => '8',
                'created_at' => '2018-11-15 10:33:48.800',
                'updated_at' => '2018-11-15 10:33:48.800',
                'created_by' => '37',
                'updated_by' => NULL,
                'deleted_at' => NULL,
                'deleted_by' => NULL,
                'inactive_at' => NULL,
                'inactive_by' => NULL,
                'type' => '4',
            ),
            5 => 
            array (
                'id' => '7',
                'unit_type_id' => '91',
                'category_project_id' => '10',
                'created_at' => '2018-11-15 11:27:32.313',
                'updated_at' => '2018-11-15 11:27:32.313',
                'created_by' => '37',
                'updated_by' => NULL,
                'deleted_at' => NULL,
                'deleted_by' => NULL,
                'inactive_at' => NULL,
                'inactive_by' => NULL,
                'type' => '4',
            ),
            6 => 
            array (
                'id' => '8',
                'unit_type_id' => '92',
                'category_project_id' => '11',
                'created_at' => '2018-11-15 11:35:17.603',
                'updated_at' => '2018-11-15 11:35:17.603',
                'created_by' => '37',
                'updated_by' => NULL,
                'deleted_at' => NULL,
                'deleted_by' => NULL,
                'inactive_at' => NULL,
                'inactive_by' => NULL,
                'type' => '2',
            ),
            7 => 
            array (
                'id' => '9',
                'unit_type_id' => '93',
                'category_project_id' => '12',
                'created_at' => '2018-11-15 11:39:24.983',
                'updated_at' => '2018-11-15 11:39:24.983',
                'created_by' => '37',
                'updated_by' => NULL,
                'deleted_at' => NULL,
                'deleted_by' => NULL,
                'inactive_at' => NULL,
                'inactive_by' => NULL,
                'type' => '9',
            ),
            8 => 
            array (
                'id' => '10',
                'unit_type_id' => '94',
                'category_project_id' => '13',
                'created_at' => '2018-11-15 11:44:19.597',
                'updated_at' => '2018-11-15 11:44:19.597',
                'created_by' => '37',
                'updated_by' => NULL,
                'deleted_at' => NULL,
                'deleted_by' => NULL,
                'inactive_at' => NULL,
                'inactive_by' => NULL,
                'type' => '8',
            ),
        ));
        
        
    }
}