<?php

use Illuminate\Database\Seeder;

class BudgetTahunansTableSeeder extends Seeder
{

    /**
     * Auto generated seed file
     *
     * @return void
     */
    public function run()
    {
        

        \DB::table('budget_tahunans')->delete();
        
        \DB::table('budget_tahunans')->insert(array (
            0 => 
            array (
                'id' => '1',
                'budget_id' => '1',
                'parent_id' => NULL,
                'no' => '0010/BDG-T/CD/X/2018/XXX/G06',
                'tahun_anggaran' => '2018',
                'description' => NULL,
                'created_at' => '2018-10-23 01:44:45.000',
                'updated_at' => '2018-10-23 01:44:45.000',
                'deleted_at' => NULL,
                'created_by' => NULL,
                'updated_by' => NULL,
                'deleted_by' => NULL,
                'inactive_at' => NULL,
                'inactive_by' => NULL,
            ),
            1 => 
            array (
                'id' => '2',
                'budget_id' => '2',
                'parent_id' => NULL,
                'no' => '0012/BDG-T/CD/X/2018/XXX/G06',
                'tahun_anggaran' => '2018',
                'description' => NULL,
                'created_at' => '2018-10-24 20:44:59.000',
                'updated_at' => '2018-10-24 20:44:59.000',
                'deleted_at' => NULL,
                'created_by' => NULL,
                'updated_by' => NULL,
                'deleted_by' => NULL,
                'inactive_at' => NULL,
                'inactive_by' => NULL,
            ),
            2 => 
            array (
                'id' => '3',
                'budget_id' => '24',
                'parent_id' => NULL,
                'no' => '0021/BDG-T/CD/XI/2018/XXX/XXX',
                'tahun_anggaran' => '2018',
                'description' => 'Fasilitas Kota',
                'created_at' => '2018-11-19 16:03:50.323',
                'updated_at' => '2018-11-19 16:03:50.323',
                'deleted_at' => NULL,
                'created_by' => NULL,
                'updated_by' => NULL,
                'deleted_by' => NULL,
                'inactive_at' => NULL,
                'inactive_by' => NULL,
            ),
            3 => 
            array (
                'id' => '4',
                'budget_id' => '27',
                'parent_id' => NULL,
                'no' => '0022/BDG-T/CD/XI/2018/XXX/XXX',
                'tahun_anggaran' => '2018',
                'description' => NULL,
                'created_at' => '2018-11-20 18:07:22.477',
                'updated_at' => '2018-11-20 18:07:22.477',
                'deleted_at' => NULL,
                'created_by' => NULL,
                'updated_by' => NULL,
                'deleted_by' => NULL,
                'inactive_at' => NULL,
                'inactive_by' => NULL,
            ),
            4 => 
            array (
                'id' => '5',
                'budget_id' => '13',
                'parent_id' => NULL,
                'no' => '0023/BDG-T/CD/XI/2018/XXX/XXX',
                'tahun_anggaran' => '2018',
                'description' => 'Migration from Project based export at 18 Oct 2018',
                'created_at' => '2018-11-22 17:28:44.227',
                'updated_at' => '2018-11-22 17:28:44.227',
                'deleted_at' => NULL,
                'created_by' => NULL,
                'updated_by' => NULL,
                'deleted_by' => NULL,
                'inactive_at' => NULL,
                'inactive_by' => NULL,
            ),
        ));
        
        
    }
}