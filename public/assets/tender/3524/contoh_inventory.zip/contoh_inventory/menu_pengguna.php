<ul id="tt1" class="easyui-tree" data-options="animate:true,dnd:true">
    <li data-options="iconCls:'icon-pesan'">
        <span><a href="?module=pesan">Pesan</a></span>
    </li>
    <li data-options="iconCls:'icon-agenda'">
        <span><a href="?module=agenda">Agenda</a></span>
    </li>

</ul>