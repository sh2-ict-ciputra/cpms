<style type="text/css">
#foto{
	margin:5px;
	border:2px solid #5c9fe9;
	-moz-border-radius: 5px 5px 5px 5px; 
	-webkit-border-radius: 5px 5px 5px 5px; 
	border-radius: 5px 5px 5px 5px; 
	-moz-box-shadow:0px 0px 20px #aaa;
    -webkit-box-shadow:0px 0px 20px #aaa;
    box-shadow:0px 0px 20spx #aaa;
}
</style>
<?php
include "inc/inc.koneksi.php";

echo "<b><center>$_SESSION[namalengkap]</center></b>";

$text	= "SELECT * FROM admins WHERE username='$_SESSION[namauser]'";
$sql	= mysql_query($text);
$data	= mysql_fetch_array($sql);
$foto	= $data[foto];
//$foto	= $sql['foto'];
if(!empty($foto)){									 
	echo "<center><img id='foto' src='foto/$foto' width='80' height='90'></center>";
	
}else{
	echo "<center><img id='foto' src='foto/kosong.png' width='80' height='90'></center>";
}
//echo $foto;
?>
