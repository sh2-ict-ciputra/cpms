<script type="text/javascript" src="modul/grafik_beli/ajax.js"></script>
<?php
echo "<div id=\"form_input\">
	<table id='judul' width='100%'>
	<tr>
		<td class='judul' colspan='2'>GRAFIK PEMBELIAN</td>
	</tr>
	</table>
	<table id='InputTable' width='100%'>
	<tr>
		<td class='label'>Tanggal</td>
		<td>:&nbsp;
		<input type='text' id='tgl1' size='10'>
		&nbsp;</td>
	</tr>
	</table>
	<div id='tombol' align='center'>
		<button type='button' id='lihat' class=\"easyui-linkbutton\" data-options=\"iconCls:'icon-grafik'\">Lihat</button>
	</div>
</div>";
?>