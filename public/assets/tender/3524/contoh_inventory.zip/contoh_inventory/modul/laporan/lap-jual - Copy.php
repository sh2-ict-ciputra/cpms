<?php
include '../../inc/inc.koneksi.php';
include '../../inc/fungsi_tanggal.php';

$tgl1	= jin_date_sql($_GET['tgl1']);
$tgl2	= jin_date_sql($_GET['tgl2']);
$field	= $_GET['field'];
$text	= $_GET['text'];
$urut	= $_GET['urut'];
$pilih	= $_GET['pilih'];

if($pilih=='tgl'){
	$where	= " WHERE tgljual BETWEEN '$tgl1' AND '$tgl2'";
}elseif($pilih=='costum'){
	if($field=='kodejual'){
		$where	= " WHERE h_jual.kodejual LIKE '%$text%'";
	}elseif($field=='tglbeli'){
		$where	= " WHERE $field='".jin_date_sql($text)."'";
	}elseif($field=='kode_barang'){
		$where	= " WHERE d_jual.kode_barang LIKE '%$text%'";
	}else{
		$where	= " WHERE $field LIKE '%$text%'";
	}
}else{
	$where	= "";
}

#ambil data di tabel dan masukkan ke array
$query = "SELECT h_jual.kodejual,tgljual, d_jual.kode_barang,nama_barang,satuan,jmljual,hargajual,(jmljual*hargajual) as total
		from h_jual
		join d_jual
		join barang
		on h_jual.kodejual=d_jual.kodejual AND d_jual.kode_barang=barang.kode_barang
		$where";
$sql = mysql_query ($query);
$data = array();
while ($row = mysql_fetch_assoc($sql)) {
array_push($data, $row);
}
 
#setting judul laporan dan header tabel
$judul = "LAPORAN DATA PENJUALAN";
$header = array(
array("label"=>"No Jual", "length"=>20, "align"=>"C"),
array("label"=>"Tanggal", "length"=>20, "align"=>"C"),
array("label"=>"Kode Barang", "length"=>30, "align"=>"C"),
array("label"=>"Nama Barang", "length"=>50, "align"=>"L"),
array("label"=>"Satuan", "length"=>20, "align"=>"L"),
array("label"=>"Jumlah", "length"=>15, "align"=>"C"),
array("label"=>"Harga Beli", "length"=>30, "align"=>"R"),
array("label"=>"Total", "length"=>30, "align"=>"R")
);

#sertakan library FPDF dan bentuk objek
require_once ("fpdf.php");
$pdf = new FPDF('L','mm','A4');
//$pdf = new FPDF();
$pdf->AddPage();
 
#tampilkan judul laporan
$pdf->SetFont('Arial','B','16');
$pdf->Cell(0,20, $judul, '0', 1, 'C');
 
#buat header tabel
$pdf->SetFont('Arial','','10');
$pdf->SetFillColor(255,0,0);
$pdf->SetTextColor(255);
$pdf->SetDrawColor(128,0,0);
foreach ($header as $kolom) {
$pdf->Cell($kolom['length'], 5, $kolom['label'], 1, '0', $kolom['align'], true);
}
$pdf->Ln();
 
#tampilkan data tabelnya
$pdf->SetFillColor(224,235,255);
$pdf->SetTextColor(0);
$pdf->SetFont('');
$fill=false;
foreach ($data as $baris) {
$i = 0;
foreach ($baris as $cell) {
	$pdf->Cell($header[$i]['length'], 5, $cell, 1, '0', $kolom['align'], $fill);
$i++;
}
$fill = !$fill;
$pdf->Ln();
}
 
#output file PDF
$pdf->Output();
?>