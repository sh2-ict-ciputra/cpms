<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>::Sistem Aplikasi Inventaris ::</title>
<link rel="stylesheet" href="css/style_login.css" type="text/css"/>

<link rel="stylesheet" type="text/css" href="css/themes/default/easyui.css">
<link rel="stylesheet" type="text/css" href="css/themes/icon.css">
<script type="text/javascript" src="js/jquery-1.7.2.min.js"></script>
<script type="text/javascript" src="js/jquery.easyui.min.js"></script>
<script type="text/javascript">

function validasi(form){
	if (form.username.value == ""){
	$.messager.show({
		title:'Info',
		msg:'Username Tidak Boleh Kosong.',
		timeout:2000,
		showType:'slide'
	});
		form.username.focus();
		return (false);
	}
	if (form.password.value == ""){
	$.messager.show({
		title:'Info',
		msg:'Password Tidak Boleh Kosong.',
		timeout:2000,
		showType:'slide'
	});
		form.password.focus();
		return (false);
	}
	return (true);
}

</script>

</head>
<body>
<div id="logo_login">
<img src="images/login_new.png" />
</div>
<div class="login-inside">
<div class="login-data">
<form name="form" action="cek_login.php" onsubmit="return validasi(this)" method="post">
<table width="100%" border="0" cellspacing="0" cellpadding="0">
<tr>
<td>
<div align="center">
<table cellpadding="0" cellspacing="0">
<tr>
<td height="25" width="50">Username</td>
<td>&nbsp;:&nbsp;<input type="text" name="username"  id="username" class="easyui-validatebox" data-options="required:true,validType:'length[1,10]'" /></td>
</tr>
<tr>
<td height="25" width="50">Password</td>
<td>&nbsp;:&nbsp;<input type="password"  name="password" id="password" class="easyui-validatebox" data-options="required:true,validType:'length[1,10]'" /></td>
</tr>
<tr>
<td height="35" colspan="2">
<div class="toolbar" align="right">
<button type="submit" name="submit" id="submit" class="easyui-linkbutton" data-options="iconCls:'icon-ok'">Login</button>
</div>
</td>
</tr>
</table>
</div>
</td>
</tr>
</table>
</div>
</div>
</body>
</html>