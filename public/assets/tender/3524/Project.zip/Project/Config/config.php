<?php

return [
    'name' => 'Project'
];
