<?php

namespace Modules\Project\Entities;

use App\CustomModel;

class HppDevelopmentCost extends CustomModel
{
    //
    
}
