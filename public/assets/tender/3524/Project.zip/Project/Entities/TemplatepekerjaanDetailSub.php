<?php

namespace Modules\Project\Entities;

use Illuminate\Database\Eloquent\Model;

class TemplatepekerjaanDetailSub extends Model
{
    protected $fillable = [];
}
