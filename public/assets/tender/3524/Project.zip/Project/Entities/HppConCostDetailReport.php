<?php

namespace Modules\Project\Entities;

use Illuminate\Database\Eloquent\Model;

class HppConCostDetailReport extends Model
{
    protected $fillable = [];
}
